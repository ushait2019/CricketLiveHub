/*
 Sports Live Hub backend
 Deploy as a Cloudflare Worker.

 Required secret:
   SPORTMONKS_TOKEN

 Optional variables:
   SPORTMONKS_SPORT = football

 Endpoint:
   GET /v1/matches?date=YYYY-MM-DD

 The Android app never receives the Sportmonks token.
*/

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Content-Type": "application/json; charset=utf-8"
};

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    const url = new URL(request.url);

    if (url.pathname === "/health") {
      return json({ ok: true, service: "sports-live-hub" });
    }

    if (url.pathname !== "/v1/matches") {
      return json({ error: "Not found" }, 404);
    }

    if (!env.SPORTMONKS_TOKEN) {
      return json({ error: "SPORTMONKS_TOKEN is not configured" }, 500);
    }

    const sport = "cricket";
    const date = url.searchParams.get("date") || new Date().toISOString().slice(0, 10);

    // Sportmonks Football v3 fixture-by-date endpoint.
    // Coverage depends on the subscription attached to the token.
    const endpoint =
      `https://cricket.sportmonks.com/api/v2.0/fixtures/date/${encodeURIComponent(date)}` +
      `?api_token=${encodeURIComponent(env.SPORTMONKS_TOKEN)}` +
      `&include=participants;scores;state;league;venue;tvStations`;

    const response = await fetch(endpoint);

    if (!response.ok) {
      const body = await response.text();
      return json({
        error: "Sports provider request failed",
        providerStatus: response.status,
        detail: body.slice(0, 500)
      }, 502);
    }

    const payload = await response.json();
    const fixtures = Array.isArray(payload.data) ? payload.data : [];

    const matches = fixtures.map(normalizeFixture).filter(Boolean);

    return json({
      date,
      sport,
      count: matches.length,
      matches
    });
  }
};

function normalizeFixture(fixture) {
  const participants = Array.isArray(fixture.participants) ? fixture.participants : [];
  const home = participants.find(p => p.meta?.location === "home") || participants[0];
  const away = participants.find(p => p.meta?.location === "away") || participants[1];

  return {
    id: String(fixture.id),
    sport: "Football",
    competition: fixture.league?.name || "Football",
    homeTeam: home?.name || "TBD",
    awayTeam: away?.name || "TBD",
    startTimeIso: fixture.starting_at || null,
    status: fixture.state?.name || (fixture.scores ? "LIVE" : "SCHEDULED"),
    officialWatchUrl: null,
    officialWatchLabel: null
  };
}

function json(value, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: corsHeaders
  });
}