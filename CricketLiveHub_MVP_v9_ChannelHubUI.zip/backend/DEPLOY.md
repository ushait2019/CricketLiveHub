# Cloud backend deployment

This backend is intentionally designed so the Sportmonks token is NOT included in the Android APK.

## Cloudflare Worker setup

1. Create a Cloudflare account.
2. Open Workers & Pages.
3. Create a Worker.
4. Upload `cloudflare-worker.js`.
5. Add the secret:
   `SPORTMONKS_TOKEN`
6. Set the variable:
   `SPORTMONKS_SPORT=football`
7. Deploy.
8. Test:
   `/health`
9. Then test:
   `/v1/matches?date=YYYY-MM-DD`

## Important

The free Sportmonks football plan currently provides a limited set of competitions, including Danish Superliga and Scottish Premiership. It is enough to prove the full technical flow, but not enough for an app that promises IPL/BPL/major global leagues.

Cricket uses a separate Sportmonks Cricket API subscription and endpoint family. Do not assume a football subscription automatically includes cricket.

## Where-to-watch

The backend deliberately leaves `officialWatchUrl` null for now.

The next layer should map a fixture/competition to an official broadcaster/platform. That mapping must use legitimate official sources. Monetag must never be substituted for this field.