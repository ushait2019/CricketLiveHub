# Cricket Live Hub

Cricket-only Android MVP focused on:
- Live cricket
- Today's matches
- Upcoming matches
- Cricket competitions
- Official "Where to Watch" links
- Favorites
- Non-intrusive advertisement area

No football, tennis, basketball, motorsport, or other sports are included.

## Legal/data model

The app is designed as a cricket information and official-watch discovery product, not as an unauthorized rebroadcasting service.

Architecture:

Android app
  -> Cloudflare Worker
  -> Licensed cricket data provider
  -> official broadcaster/platform mapping

The Sportmonks API token must remain server-side.

## Monetag

Advertisement SmartLink:
https://uplcm.com/4/12146519

It is an advertisement destination only and must never be presented as an official cricket stream.

## Target

Initial target: approximately 100 users.

The backend should cache cricket data aggressively so the app does not create one provider request per user.