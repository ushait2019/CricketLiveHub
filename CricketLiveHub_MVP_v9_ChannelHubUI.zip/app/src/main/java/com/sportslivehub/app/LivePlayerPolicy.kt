package com.sportslivehub.app

import com.sportslivehub.app.data.LiveVideoSource

object LivePlayerPolicy {
    fun canPlayInsideApp(source: LiveVideoSource): Boolean {
        return source.isOfficial && source.embeddingAllowed &&
            source.playbackUrl.isNotBlank()
    }
}