package com.sportslivehub.app.data

class DemoSportsDataRepository : SportsDataRepository {
    override suspend fun getMatches(): List<MatchItem> = getDemoMatches()

    fun getDemoMatches(): List<MatchItem> = listOf(
        MatchItem(
            id = "demo-bpl-1",
            competition = "Bangladesh Premier League",
            homeTeam = "BPL Team A",
            awayTeam = "BPL Team B",
            startTimeIso = "2026-10-29T19:00:00+06:00",
            status = "LIVE"
        ),
        MatchItem(
            id = "demo-int-1",
            competition = "International Cricket",
            homeTeam = "Bangladesh",
            awayTeam = "India",
            startTimeIso = "2026-10-29T21:00:00+06:00",
            status = "SCHEDULED"
        ),
        MatchItem(
            id = "demo-ipl-1",
            competition = "Indian Premier League",
            homeTeam = "IPL Team A",
            awayTeam = "IPL Team B",
            startTimeIso = "2026-10-30T20:00:00+06:00",
            status = "SCHEDULED"
        )
    )

    fun getChannelsForMatch(matchId: String): List<CricketChannel> = when (matchId) {
        "demo-bpl-1" -> listOf(
            CricketChannel(
                id = "tsports-bd",
                name = "T Sports",
                country = "Bangladesh",
                playbackType = ChannelPlaybackType.OFFICIAL_WEB,
                isOfficialSource = true,
                inAppPlaybackAllowed = false
            ),
            CricketChannel(
                id = "nagorik-bd",
                name = "Nagorik TV",
                country = "Bangladesh",
                playbackType = ChannelPlaybackType.OFFICIAL_WEB,
                isOfficialSource = true,
                inAppPlaybackAllowed = false
            ),
            CricketChannel(
                id = "rabbithole-bd",
                name = "Rabbithole",
                country = "Bangladesh",
                playbackType = ChannelPlaybackType.OFFICIAL_WEB,
                isOfficialSource = true,
                inAppPlaybackAllowed = false
            )
        )
        else -> listOf(
            CricketChannel(
                id = "official-source",
                name = "Official broadcaster",
                country = "Bangladesh",
                playbackType = ChannelPlaybackType.OFFICIAL_WEB,
                isOfficialSource = true,
                inAppPlaybackAllowed = false
            )
        )
    }
}
