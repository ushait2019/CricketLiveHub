package com.sportslivehub.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.sportslivehub.app.data.ChannelPlaybackType
import com.sportslivehub.app.data.CricketChannel
import com.sportslivehub.app.data.DemoSportsDataRepository
import com.sportslivehub.app.data.MatchItem

class MainActivity : AppCompatActivity() {

    private val monetagLink = "https://uplcm.com/4/12146519"
    private val repository = DemoSportsDataRepository()
    private val matches = repository.getDemoMatches()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderHome("All Matches")
    }

    private fun renderHome(category: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 8)
            setBackgroundColor(Color.rgb(10, 12, 16))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(TextView(this).apply {
            text = "Cricket Live Hub"
            textSize = 25f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        })
        titleBox.addView(TextView(this).apply {
            text = "Live cricket TV + official channels"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 3, 0, 0)
        })
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply {
            text = "🔔"
            textSize = 24f
            setPadding(12, 0, 4, 0)
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Match alerts will be connected with the live backend later.", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(header)

        val tabs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, 14, 0, 8)
        }
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("All Matches", "Live Now", "Today", "Upcoming", "Favorites").forEach { label ->
            tabRow.addView(TextView(this).apply {
                text = label
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(18, 10, 18, 10)
                setTextColor(if (label == category) Color.WHITE else Color.LTGRAY)
                setBackgroundColor(if (label == category) Color.rgb(45, 55, 70) else Color.rgb(24, 27, 33))
                setOnClickListener { renderHome(label) }
            }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, 8, 0) })
        }
        tabs.addView(tabRow)
        root.addView(tabs)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val filtered = when (category) {
            "Live Now" -> matches.filter { it.status == "LIVE" }
            "Upcoming" -> matches.filter { it.status == "SCHEDULED" }
            "Favorites" -> emptyList()
            else -> matches
        }

        if (filtered.isEmpty()) {
            content.addView(TextView(this).apply {
                text = if (category == "Favorites") "No favorite matches yet." else "No matches found."
                textSize = 15f
                setTextColor(Color.LTGRAY)
                gravity = Gravity.CENTER
                setPadding(0, 50, 0, 50)
            })
        } else {
            filtered.forEach { addMatchCard(content, it) }
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(TextView(this).apply {
            text = "Advertisement"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.GRAY)
            setPadding(0, 8, 0, 8)
            setOnClickListener { openExternal(monetagLink) }
        })
        root.addView(TextView(this).apply {
            text = "Home     •     Live     •     Matches     •     ⭐ Favorites"
            gravity = Gravity.CENTER
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 10)
        })
        setContentView(root)
    }

    private fun addMatchCard(parent: LinearLayout, match: MatchItem) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(Color.rgb(23, 26, 32))
        }
        card.addView(TextView(this).apply {
            text = "🏏  ${match.homeTeam}  vs  ${match.awayTeam}"
            textSize = 17f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        })
        card.addView(TextView(this).apply {
            text = "${match.competition}  •  ${match.status}"
            textSize = 12.5f
            setTextColor(Color.LTGRAY)
            setPadding(0, 5, 0, 10)
        })

        val watch = Button(this).apply {
            text = if (match.status == "LIVE") "🔴  Watch Live" else "Where to Watch"
            isAllCaps = false
            setOnClickListener { showChannelHub(match) }
        }
        card.addView(watch)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 10) })
    }

    private fun showChannelHub(match: MatchItem) {
        val channels = repository.getChannelsForMatch(match.id)
        val dialog = android.app.Dialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 20)
            setBackgroundColor(Color.rgb(18, 21, 27))
        }
        root.addView(TextView(this).apply {
            text = "LIVE TV • ${match.homeTeam} vs ${match.awayTeam}"
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Official sources available for your region"
            textSize = 12.5f
            setTextColor(Color.LTGRAY)
            setPadding(0, 5, 0, 14)
        })

        channels.forEach { channel ->
            addChannelRow(root, channel, match.status == "LIVE", dialog)
        }
        root.addView(TextView(this).apply {
            text = "Only authorized in-app streams can play inside Cricket Live Hub."
            textSize = 11f
            setTextColor(Color.GRAY)
            setPadding(0, 14, 0, 0)
        })
        dialog.setContentView(root)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), -2)
    }

    private fun addChannelRow(parent: LinearLayout, channel: CricketChannel, isLive: Boolean, dialog: android.app.Dialog) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 10, 8, 10)
            setBackgroundColor(Color.rgb(28, 32, 40))
        }
        val name = TextView(this).apply {
            text = "🏏  ${channel.name}\n${channel.country}"
            textSize = 14f
            setTextColor(Color.WHITE)
        }
        row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))

        val action = Button(this).apply {
            text = if (isLive) "WATCH LIVE" else "SOURCE"
            isAllCaps = false
            setOnClickListener {
                if (channel.inAppPlaybackAllowed && channel.liveUrl != null) {
                    openAuthorizedPlayer(channel)
                } else if (channel.liveUrl != null) {
                    openExternal(channel.liveUrl)
                } else {
                    Toast.makeText(this@MainActivity, "This official source is not connected to an in-app stream yet.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        row.addView(action)
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 8) })
    }

    private fun openAuthorizedPlayer(channel: CricketChannel) {
        if (!channel.inAppPlaybackAllowed || channel.liveUrl.isNullOrBlank()) return
        when (channel.playbackType) {
            ChannelPlaybackType.HLS, ChannelPlaybackType.DASH -> {
                startActivity(Intent(this, LivePlayerActivity::class.java).apply {
                    putExtra(LivePlayerActivity.EXTRA_STREAM_URL, channel.liveUrl)
                })
            }
            ChannelPlaybackType.YOUTUBE_LIVE, ChannelPlaybackType.OFFICIAL_WEB -> openExternal(channel.liveUrl)
        }
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "Unable to open the link.", Toast.LENGTH_SHORT).show()
        }
    }


}