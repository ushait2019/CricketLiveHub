package com.sportslivehub.app.data

data class CricketChannel(
    val id: String,
    val name: String,
    val country: String,
    val logoUrl: String? = null,
    val liveUrl: String? = null,
    val playbackType: ChannelPlaybackType = ChannelPlaybackType.OFFICIAL_WEB,
    val isOfficialSource: Boolean = true,
    val inAppPlaybackAllowed: Boolean = false
)

enum class ChannelPlaybackType {
    HLS,
    DASH,
    YOUTUBE_LIVE,
    OFFICIAL_WEB
}

data class ChannelMatchAvailability(
    val channel: CricketChannel,
    val matchId: String?,
    val isLive: Boolean
)