# Cricket Live — final architecture

## What can be changed without rebuilding the APK
- official source URLs / channel catalog
- match metadata and availability (when backend is connected)
- home notice, text, image/video and optional click URL
- enable/disable ads
- Monetag SmartLink URL and enable flag
- LevelPlay App Key / Banner Ad Unit ID values **only if the deployed app has a remote-config endpoint and the SDK accepts the runtime values**
- minimum/latest app version and update notice

## What still requires an APK/AAB release
- new Kotlin/Android code
- new SDK/library dependencies
- new permissions
- UI/feature changes not already implemented
- changing package/applicationId or signing identity

## Live video policy
The app supports authorized HLS/DASH/YouTube Live playback when a rights holder explicitly permits in-app playback. The built-in catalog uses official broadcaster destinations when in-app playback is not authorized. The app does not scrape, proxy, rehost, or extract hidden streams.

## Ads
LevelPlay is initialized with the configured App Key and loads the Banner Ad Unit ID after initialization succeeds. Ad delivery depends on LevelPlay/mediation inventory, policy approval, network connectivity and fill; no ad network can guarantee 100% fill.

## Security
LevelPlay Platform API Secret Key and Refresh Token belong on the server only. Never place them in the APK, GitHub, or the Android source code.
