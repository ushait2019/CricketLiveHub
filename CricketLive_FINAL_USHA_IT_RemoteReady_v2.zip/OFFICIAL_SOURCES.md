# Official live sources

Verified official destinations used by the app:
- T Sports Live TV: https://www.tsports.com/live-tv
- Toffee: https://toffeelive.com/en
- Rabbithole Live: https://www.rabbitholebd.com/see-all/rabbithole-home/live
- Nagorik TV: https://nagoriktv.com/

The ICC lists T Sports and Nagorik TV as Bangladesh linear broadcasters and Rabbithole as a Bangladesh digital platform for the ICC Men’s T20 World Cup 2026. Toffee is also an official Bangladeshi streaming platform and is used by rights holders for sports/TV distribution.

Important: the app opens these official destinations unless an authorized in-app playback URL is supplied. It never extracts hidden stream URLs or rehosts broadcaster content.
