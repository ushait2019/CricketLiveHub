# Cricket Live — USHA IT

Cricket Live is a TV-hub style Android app for discovering live cricket and official broadcaster destinations.

## Android identity
- Application ID: `com.ushait.cricketlive`
- App name: `Cricket Live`

## Build

This project is designed to build with Android Gradle Plugin 8.13.0, Kotlin 2.2.20 and Java 17.

## LevelPlay
- App Key: `291bd9bcd`
- Banner Ad Unit ID: `rfvqbutm8q247lt6`

The app initializes LevelPlay before loading the banner.

## Remote control
The APK contains a remote configuration client. Once connected to the deployed Cloudflare Worker `/v1/config`, the following can be changed without rebuilding the APK:
- official source/channel URLs
- source enablement and playback flags
- home notice text/link
- ad enablement and ad unit configuration fields
- app update notice/version metadata

New Android code, SDKs, permissions or major features still require a new APK/AAB.

## Live video
Only rights-holder-authorized in-app HLS/DASH/YouTube playback is supported. Official broadcaster destinations are used when in-app playback is not authorized. The app does not scrape or rehost hidden streams.

## Ads
LevelPlay banner delivery is subject to account approval, mediation inventory, network connectivity and fill. 100% ad delivery cannot be guaranteed.

## Developer
USHA IT
© 2026 USHA IT. All Rights Reserved.
