package com.ushait.cricketlive

import com.ushait.cricketlive.data.LiveVideoSource

object LivePlayerPolicy {
    fun canPlayInsideApp(source: LiveVideoSource): Boolean {
        return source.isOfficial && source.embeddingAllowed &&
            source.playbackUrl.isNotBlank()
    }
}