package com.ushait.cricketlive

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Official YouTube embed surface.
 *
 * Only use this for a video/live URL published by the rights holder where
 * embedding is permitted. No stream URL is extracted or re-hosted.
 */
class YouTubePlayerActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val url = intent.getStringExtra(EXTRA_YOUTUBE_URL)
        val videoId = extractVideoId(url)
        if (videoId.isNullOrBlank()) {
            finish()
            return
        }

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false
            }
        }
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))

        val label = TextView(this).apply {
            text = "Official YouTube live"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0x66000000)
        }
        root.addView(label, FrameLayout.LayoutParams(-2, -2).apply {
            topMargin = 12
            leftMargin = 12
        })

        setContentView(root)

        val embedUrl = "https://www.youtube-nocookie.com/embed/$videoId?autoplay=1&playsinline=1&rel=0"
        webView.loadUrl(embedUrl)
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.loadUrl("about:blank")
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    private fun extractVideoId(rawUrl: String?): String? {
        if (rawUrl.isNullOrBlank()) return null
        return try {
            val uri = android.net.Uri.parse(rawUrl)
            when {
                uri.host.equals("youtu.be", ignoreCase = true) -> uri.pathSegments.firstOrNull()
                uri.path?.startsWith("/embed/") == true -> uri.pathSegments.getOrNull(1)
                uri.getQueryParameter("v") != null -> uri.getQueryParameter("v")
                else -> null
            }?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{6,20}")) }
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        const val EXTRA_YOUTUBE_URL = "official_youtube_url"
    }
}
