package com.ushait.cricketlive.data

data class MatchResponse(
    val date: String,
    val sport: String,
    val count: Int,
    val matches: List<MatchItem>
)

// Keep the HTTP layer separate from UI. A Retrofit implementation can be added
// once the cloud Worker URL is available.
interface SportsLiveHubApi {
    // GET /v1/matches?date=YYYY-MM-DD
}