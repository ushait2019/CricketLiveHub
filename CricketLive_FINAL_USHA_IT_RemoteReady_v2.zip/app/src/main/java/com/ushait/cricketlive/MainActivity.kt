package com.ushait.cricketlive

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ushait.cricketlive.remote.RemoteAppConfig
import com.ushait.cricketlive.remote.RemoteConfigManager
import kotlinx.coroutines.launch
import com.ushait.cricketlive.data.ChannelPlaybackType
import com.ushait.cricketlive.data.CricketChannel
import com.ushait.cricketlive.data.DemoSportsDataRepository
import com.ushait.cricketlive.data.MatchItem
import com.unity3d.mediation.LevelPlay
import com.unity3d.mediation.LevelPlayInitError
import com.unity3d.mediation.LevelPlayInitListener
import com.unity3d.mediation.LevelPlayInitRequest

class MainActivity : AppCompatActivity() {

    private val monetagLink = "https://uplcm.com/4/12146519"
    private val repository = DemoSportsDataRepository()
    private val matches = repository.getDemoMatches()
    private var remoteConfig = RemoteAppConfig()
    private var updateNoticeShownThisSession = false
    private var levelPlayAppKey = LevelPlayConfig.APP_KEY
    private var levelPlayBannerId = LevelPlayConfig.BANNER_AD_UNIT_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleConfigIntent(intent)
        lifecycleScope.launch {
            val fetched = RemoteConfigManager.fetch(this@MainActivity)
            if (fetched != null) {
                remoteConfig = fetched
                if (fetched.levelPlayEnabled && fetched.levelPlayAppKey.isNotBlank()) levelPlayAppKey = fetched.levelPlayAppKey
                if (fetched.levelPlayEnabled && fetched.levelPlayBannerAdUnitId.isNotBlank()) levelPlayBannerId = fetched.levelPlayBannerAdUnitId
            }
            checkForUpdateOncePerSession()
            initializeLevelPlay()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleConfigIntent(intent)
    }

    private fun handleConfigIntent(intent: Intent?) {
        val data = intent?.data ?: return
        if (data.scheme == "cricketlive" && data.host == "config") {
            val url = data.getQueryParameter("url")
            if (!url.isNullOrBlank() && (url.startsWith("https://"))) {
                RemoteConfigManager.setConfigUrl(this, url)
                Toast.makeText(this, "Remote control connected.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun checkForUpdateOncePerSession() {
        if (updateNoticeShownThisSession) return
        if (remoteConfig.latestVersionCode <= BuildConfig.VERSION_CODE) return
        updateNoticeShownThisSession = true
        val mandatory = remoteConfig.minVersionCode > BuildConfig.VERSION_CODE
        val builder = android.app.AlertDialog.Builder(this)
            .setTitle("Cricket Live update available")
            .setMessage(remoteConfig.updateMessage.ifBlank { "Version ${remoteConfig.latestVersionName} is available." })
            .setPositiveButton("UPDATE") { _, _ ->
                if (remoteConfig.updateUrl.isNotBlank()) openExternal(remoteConfig.updateUrl)
            }
        if (!mandatory) {
            builder.setNegativeButton("SKIP THIS VERSION", null)
        } else {
            builder.setCancelable(false)
        }
        builder.show()
    }

    private fun initializeLevelPlay() {
        if (!remoteConfig.levelPlayEnabled || levelPlayAppKey.isBlank() || levelPlayBannerId.isBlank()) {
            renderHome("All Matches")
            return
        }

        val initRequest = LevelPlayInitRequest.Builder(levelPlayAppKey).build()
        LevelPlay.init(this, initRequest, object : LevelPlayInitListener {
            override fun onInitSuccess(configuration: com.unity3d.mediation.LevelPlayConfiguration) {
                levelPlayInitialized = true
                runOnUiThread { renderHome("All Matches") }
            }

            override fun onInitFailed(error: LevelPlayInitError) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Ad service unavailable right now.", Toast.LENGTH_SHORT).show()
                    renderHome("All Matches")
                }
            }
        })
    }

    override fun onDestroy() {
        adController?.destroy()
        adController = null
        super.onDestroy()
    }

    private fun renderHome(category: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 8)
            setBackgroundColor(Color.rgb(10, 12, 16))
        }

        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(16, bars.top + 10, 16, bars.bottom + 8)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(TextView(this).apply {
            text = "Cricket Live"
            textSize = 25f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        })
        titleBox.addView(TextView(this).apply {
            text = "Live cricket TV + official channels"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 3, 0, 0)
        })
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply {
            text = "🔔"
            textSize = 24f
            setPadding(12, 0, 4, 0)
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Match alerts will be connected with the live backend later.", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(header)

        val tabs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, 14, 0, 8)
        }
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("All Matches", "Live Now", "Today", "Upcoming", "Favorites").forEach { label ->
            tabRow.addView(TextView(this).apply {
                text = label
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(18, 10, 18, 10)
                setTextColor(if (label == category) Color.WHITE else Color.LTGRAY)
                setBackgroundColor(if (label == category) Color.rgb(45, 55, 70) else Color.rgb(24, 27, 33))
                setOnClickListener { renderHome(label) }
            }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, 8, 0) })
        }
        tabs.addView(tabRow)
        root.addView(tabs)

        if (remoteConfig.homeNoticeEnabled && (remoteConfig.homeNoticeTitle.isNotBlank() || remoteConfig.homeNoticeText.isNotBlank())) {
            val notice = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(Color.rgb(25, 30, 38))
                setOnClickListener {
                    if (remoteConfig.homeNoticeClickUrl.isNotBlank()) openExternal(remoteConfig.homeNoticeClickUrl)
                }
            }
            if (remoteConfig.homeNoticeTitle.isNotBlank()) notice.addView(TextView(this).apply {
                text = remoteConfig.homeNoticeTitle
                textSize = 15f
                setTextColor(Color.WHITE)
                setTypeface(null, Typeface.BOLD)
            })
            if (remoteConfig.homeNoticeText.isNotBlank()) notice.addView(TextView(this).apply {
                text = remoteConfig.homeNoticeText
                textSize = 12.5f
                setTextColor(Color.LTGRAY)
                setPadding(0, 5, 0, 0)
            })
            root.addView(notice, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 10) })
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val filtered = when (category) {
            "Live Now" -> matches.filter { it.status == "LIVE" }
            "Upcoming" -> matches.filter { it.status == "SCHEDULED" }
            "Favorites" -> emptyList()
            else -> matches
        }

        if (filtered.isEmpty()) {
            content.addView(TextView(this).apply {
                text = if (category == "Favorites") "No favorite matches yet." else "No matches found."
                textSize = 15f
                setTextColor(Color.LTGRAY)
                gravity = Gravity.CENTER
                setPadding(0, 50, 0, 50)
            })
        } else {
            filtered.forEach { addMatchCard(content, it) }
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val adLabel = TextView(this).apply {
            text = "Advertisement"
            textSize = 10.5f
            gravity = Gravity.CENTER
            setTextColor(Color.GRAY)
            setPadding(0, 6, 0, 4)
        }
        root.addView(adLabel)

        val adContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(15, 17, 22))
        }
        root.addView(adContainer, LinearLayout.LayoutParams(-1, dp(50)).apply {
            setMargins(0, 0, 0, 4)
        })
        adController?.destroy()
        adController = LevelPlayBannerController(this, levelPlayAppKey, levelPlayBannerId, remoteConfig.levelPlayEnabled)
        adController?.attach(adContainer)

        root.addView(TextView(this).apply {
            text = "Home     •     Live     •     Matches     •     ⭐ Favorites"
            gravity = Gravity.CENTER
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 10)
        })
        setContentView(root)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun addMatchCard(parent: LinearLayout, match: MatchItem) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(Color.rgb(23, 26, 32))
        }
        card.addView(TextView(this).apply {
            text = "🏏  ${match.homeTeam}  vs  ${match.awayTeam}"
            textSize = 17f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        })
        card.addView(TextView(this).apply {
            text = "${match.competition}  •  ${match.status}"
            textSize = 12.5f
            setTextColor(Color.LTGRAY)
            setPadding(0, 5, 0, 10)
        })

        val watch = Button(this).apply {
            text = if (match.status == "LIVE") "🔴  Watch Live" else "Where to Watch"
            isAllCaps = false
            setOnClickListener { showChannelHub(match) }
        }
        card.addView(watch)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 10) })
    }

    private fun showChannelHub(match: MatchItem) {
        val channels = if (remoteConfig.channels.isNotEmpty()) remoteConfig.channels else repository.getChannelsForMatch(match.id)
        val dialog = android.app.Dialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 20)
            setBackgroundColor(Color.rgb(18, 21, 27))
        }
        root.addView(TextView(this).apply {
            text = "LIVE TV • ${match.homeTeam} vs ${match.awayTeam}"
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Official broadcaster sources • watch through the rights holder"
            textSize = 12.5f
            setTextColor(Color.LTGRAY)
            setPadding(0, 5, 0, 14)
        })

        channels.forEach { channel ->
            addChannelRow(root, channel, match.status == "LIVE", dialog)
        }
        root.addView(TextView(this).apply {
            text = "Live video plays in Cricket Live only when the rights holder permits in-app playback."
            textSize = 11f
            setTextColor(Color.GRAY)
            setPadding(0, 14, 0, 0)
        })
        dialog.setContentView(root)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), -2)
    }

    private fun addChannelRow(parent: LinearLayout, channel: CricketChannel, isLive: Boolean, dialog: android.app.Dialog) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 10, 8, 10)
            setBackgroundColor(Color.rgb(28, 32, 40))
        }
        val name = TextView(this).apply {
            text = "🏏  ${channel.name}\n${channel.country}"
            textSize = 14f
            setTextColor(Color.WHITE)
        }
        row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))

        val hasInAppSource = channel.isOfficialSource && channel.inAppPlaybackAllowed && !channel.liveUrl.isNullOrBlank()
        val hasOfficialDestination = !channel.officialUrl.isNullOrBlank() || !channel.liveUrl.isNullOrBlank()
        val action = Button(this).apply {
            text = when {
                hasInAppSource && isLive -> "WATCH LIVE"
                hasOfficialDestination && isLive -> "WATCH OFFICIAL"
                hasOfficialDestination -> "OPEN SOURCE"
                else -> "UNAVAILABLE"
            }
            isAllCaps = false
            isEnabled = hasOfficialDestination
            setOnClickListener {
                openChannel(channel)
            }
        }
        row.addView(action)
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 8) })
    }

    private fun openChannel(channel: CricketChannel) {
        val liveUrl = channel.liveUrl
        if (channel.isOfficialSource && channel.inAppPlaybackAllowed && !liveUrl.isNullOrBlank()) {
            when (channel.playbackType) {
                ChannelPlaybackType.HLS, ChannelPlaybackType.DASH -> {
                    startActivity(Intent(this, LivePlayerActivity::class.java).apply {
                        putExtra(LivePlayerActivity.EXTRA_STREAM_URL, liveUrl)
                    })
                }
                ChannelPlaybackType.YOUTUBE_LIVE -> {
                    startActivity(Intent(this, YouTubePlayerActivity::class.java).apply {
                        putExtra(YouTubePlayerActivity.EXTRA_YOUTUBE_URL, liveUrl)
                    })
                }
                ChannelPlaybackType.OFFICIAL_WEB -> openExternal(channel.officialUrl ?: liveUrl)
            }
            return
        }

        val officialDestination = channel.officialUrl ?: liveUrl
        if (!officialDestination.isNullOrBlank()) {
            openExternal(officialDestination)
        } else {
            Toast.makeText(this, "Official live source is not available right now.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "Unable to open the link.", Toast.LENGTH_SHORT).show()
        }
    }


}