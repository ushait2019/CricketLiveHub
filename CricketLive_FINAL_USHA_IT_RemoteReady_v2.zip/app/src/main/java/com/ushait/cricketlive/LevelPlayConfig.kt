package com.ushait.cricketlive

/**
 * LevelPlay configuration for Cricket Live.
 * The App Key and Banner Ad Unit ID are public SDK identifiers.
 * Platform API secrets must NEVER be placed in the APK.
 */
object LevelPlayConfig {
    const val APP_KEY = "291bd9bcd"
    const val BANNER_AD_UNIT_ID = "rfvqbutm8q247lt6"

    val isConfigured: Boolean
        get() = APP_KEY.isNotBlank() && BANNER_AD_UNIT_ID.isNotBlank()
}
