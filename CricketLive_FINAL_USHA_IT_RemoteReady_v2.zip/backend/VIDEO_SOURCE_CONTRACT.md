# Authorized video source contract

The backend may return:

{
  "videoSources": [
    {
      "id": "source-123",
      "channelName": "Official Channel",
      "country": "BD",
      "type": "YOUTUBE_LIVE",
      "playbackUrl": "https://www.youtube.com/watch?v=...",
      "isOfficial": true,
      "embeddingAllowed": true
    }
  ]
}

If the rights holder does not authorize embedding/playback:
- do not put the raw stream URL in the API response;
- return an official destination URL instead;
- let Android open that official destination externally.

This keeps the backend from becoming a stream-rehosting service.