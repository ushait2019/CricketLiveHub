# Cricket Live — LevelPlay setup

Configured values:
- App: Cricket Live
- Platform: Android
- LevelPlay App Key: `291bd9bcd`
- Banner Ad Unit: `rfvqbutm8q247lt6`
- Banner refresh: 30 seconds

The APK initializes LevelPlay with the App Key and loads the Banner only after initialization succeeds.

**Important:** ad delivery cannot be guaranteed 100%. It depends on network connectivity, mediation inventory, account/ad-unit approval, policy status, and fill.

Never place the LevelPlay Platform API Secret Key or Refresh Token in the APK. Those credentials belong on the server only.
