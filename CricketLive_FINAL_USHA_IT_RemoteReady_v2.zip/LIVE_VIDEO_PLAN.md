# Cricket Live TV: implementation plan

The product goal is TV-style live viewing, but only from authorized sources.

## Source types

1. Official HLS/DASH stream
   - Best option for an in-app player.
   - Requires the broadcaster/content owner to authorize playback.

2. Official YouTube live
   - Can be opened/embedded when the rights holder publishes the match on YouTube and permits the intended playback.

3. Official broadcaster web/app
   - If in-app embedding is not authorized, open the official destination instead of copying the stream.

## What the app will NOT do

- Scrape IPTV websites.
- Extract hidden M3U/HLS links from unauthorized sites.
- Rehost a broadcaster's stream.
- Use random "free sports streaming" sources.
- Pretend an ad SmartLink is a TV channel.

## Why this matters

ICC publishes territory-specific official broadcaster lists. For example, the ICC Men's T20 World Cup 2026 page lists Bangladesh rights holders and their TV/digital outlets. These lists can be used to populate a "Where to Watch" directory, but they do not by themselves grant us permission to rebroadcast or embed the stream.

## Example product flow

LIVE NOW
  ↓
Bangladesh vs India
  ↓
Watch Live
  ↓
Official source available?
  ├─ Yes + embedding/playback authorized → in-app TV player
  └─ No → official broadcaster page/app

## First real-video target

The safest first test is a cricket match that its rights holder is itself publishing as an authorized live video, such as an official YouTube live event or an explicitly embeddable official player.

We should test the player with that source before attempting commercial broadcast feeds.